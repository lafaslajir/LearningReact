import routes from './routes';
function App() {
  return routes;
}

export default App;