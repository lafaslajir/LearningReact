export const SiteFooter = ()=><div className="copyright">
Powered by: <a href="https://templated.co/">Templated</a>.
</div>