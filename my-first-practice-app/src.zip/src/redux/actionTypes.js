export const NAVIGATE = 'NAVIGATE';
